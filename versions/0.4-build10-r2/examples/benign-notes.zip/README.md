Orchard harmless trial for build7. Two plain text documents only.
